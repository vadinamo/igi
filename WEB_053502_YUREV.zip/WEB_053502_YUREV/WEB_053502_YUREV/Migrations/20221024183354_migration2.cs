﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WEB_053502_YUREV.Migrations
{
    public partial class migration2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
