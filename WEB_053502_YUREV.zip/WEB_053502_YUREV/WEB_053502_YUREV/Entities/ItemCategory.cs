namespace WEB_053502_YUREV.Entities;

public class ItemCategory
{
    public Guid Id { get; set; }
    public string? CategoryName { get; set; }
}