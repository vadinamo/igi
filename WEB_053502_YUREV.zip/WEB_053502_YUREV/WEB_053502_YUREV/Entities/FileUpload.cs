namespace WEB_053502_YUREV.Entities;

public class FileUpload
{
    public IFormFile FormFile { get; set; }
}