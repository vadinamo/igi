using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WEB_053502_YUREV.Areas.Admin.Pages;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}